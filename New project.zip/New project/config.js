window.KARTU_CONFIG = {"supabaseUrl": "https://fvmantcrremlqgehbces.supabase.co", "supabasePublishableKey": "sb_publishable_0QYAdKRi3hugTncA3CtoXA_R8QXC250"};
